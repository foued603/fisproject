<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en" >
 <?php 
	if(!empty($_SESSION['id'])){ ?>
	<script>
	document.location.href="home/index.php";
	</script>	
	<?php } ?>
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
<link rel="stylesheet" href="./style.css">

</head>
<body>
<!-- partial:index.partial.html -->
<input class="logic-checkbox" type="checkbox" id="toggleGame"/>
<input class="logic-checkbox" type="checkbox" id="HowToPlayPopup"/>
<input class="logic-checkbox" type="checkbox" id="whoAmIPopup"/>
<input class="logic-checkbox" type="checkbox" id="GraphicsLevel"/>
<section class="game-menu-frame">
  <header class="game-header">
    <h1 class="game-title"> 
      <div class="line-1"> Serious Game</div>
      <div class="line-2">By FIS</div>
      <div class="line-3">Let's enjoy together!</div>
    </h1>
  </header>
  <nav class="game-nav">
    <h2 class="game-nav-title">Main Menu</h2>
    <ul class="game-nav-list">
      <li class="game-nav-item"> 
        <label class="game-nav-button" for="toggleGame" tabindex="0">Start Jeux</label>
      </li>
      <li class="game-nav-item"> 
        <label class="game-nav-button" for="HowToPlayPopup" tabindex="0">inscription</label>
      </li>
      <li class="game-nav-item"> 
        <label class="game-nav-button" for="GraphicsLevel" tabindex="0" >Connexion</label>
      </li>
      <li class="game-nav-item"> 
        <label class="game-nav-button" for="whoAmIPopup" tabindex="0">instruction</label>
      </li>
      <li class="game-nav-item"> <a class="game-nav-button" href="https://eladsc.com/">Quitter</a></li>
    </ul>
    <p class="note">Let's beat this on together and on the way spend time doing good.</p>
  </nav>
  <div class="corona-promo-virus-1">
    <label class="corona-virus">
      <div class="body">
        <div class="scalp"><span class="hair1"></span><span class="hair2"></span><span class="hair3"></span><span class="hair4"></span><span class="hair5"></span><span class="hair6"></span><span class="hair7"></span><span class="hair8"></span><span class="hair9"></span><span class="hair10"></span><span class="hair11"></span><span class="hair12"></span>
        </div>
        <div class="eye1"></div>
        <div class="eye2"></div>
      </div>
    </label>
  </div>
  <div class="corona-promo-virus-2">
    <label class="corona-virus">
      <div class="body">
        <div class="scalp"><span class="hair1"></span><span class="hair2"></span><span class="hair3"></span><span class="hair4"></span><span class="hair5"></span><span class="hair6"></span><span class="hair7"></span><span class="hair8"></span><span class="hair9"></span><span class="hair10"></span><span class="hair11"></span><span class="hair12"></span>
        </div>
        <div class="eye1"></div>
        <div class="eye2"></div>
      </div>
    </label>
  </div>
</section>



<section class="popup common-content" id="whoAmI">
  <label class="close-button" for="whoAmIPopup" tabindex="0">x</label>
  <h3 class="common-title">Who Am I ?</h3>
  <p>II’m Elad Shechter, a Web Developer specializing in CSS & HTML design and architecture.</p>
  <p>You can see more of my stuff on my website <a href="https://www.eladsc.com/" target="_blank">eladsc.com</a> and follow me on <a href="https://www.twitter.com/eladsc" target="_blank">twitter.com/eladsc</a>.</p><img src="https://i0.wp.com/eladsc.com/wp-content/uploads/2019/11/10354134_10152745572181933_3605798323082127817_n.jpg" alt="Elad Shechter"/>
  <label class="game-nav-button" for="whoAmIPopup" tabindex="0">Close</label>
</section>
<section class="popup common-content" id="HowToPlay">
  <label class="close-button" for="HowToPlayPopup" tabindex="0">x</label>
  <h3 class="common-title">Inscription</h3>
  <p>E_Number :   <input type="text" name="login"/></p>
 <p> Login : <input type="text" name="login"/></p>
  <p>Mot de passe :<input type="text" name="login"/></p>
    <p>Position :<input type="text" name="login"/></p>
    <p> <input type="button" name="login" value="Valider"/></p>

  
  <label class="game-nav-button" for="HowToPlayPopup" tabindex="0">Close</label>
</section>
<!-- partial -->
  <script  src="./script.js"></script>

</body>
</html>
