<!DOCTYPE html>
<?php session_start(); ?>

<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>logs</title>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js" type="text/javascript"></script>
	<link rel="stylesheet" type="text/css" href="css/demo.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel="stylesheet" href="css/logtable.css">
		<link rel="stylesheet" type="text/css" href="css/normalize.css" />
		<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.3.0/css/font-awesome.min.css" />
				<link rel="stylesheet" type="text/css" href="css/menustyle.css" />

</head>
<?php 


include('../inc/connect.php');
include('../inc/select_user.php');

?>
<?php if(empty($_SESSION['id'])){?>
				<?php }if(!empty($_SESSION['id'])){
				$user = user($_SESSION['id']);	
				 }?>
<body>
	<nav class="navbar">
  <ul class="menu">

    <li>
      <a href="index.php">Home</a>
    </li>
    <li>
      <a href="profile.php">Profile</a>
    </li>
    <li>
      <a href="logs.php">Logs</a>
    </li>
    <li>
      <a href="settigns.php">Setttings</a>
    </li>
    <li>
      <a href="other.php">instruction</a>
    </li>
		 <li>
      <a href="../inc/logout.php">Logout</a>
    </li>
    <ul>
</nav>
		
<!-- partial:index.partial.html -->
<h1>Logs</h1>
<table class="rwd-table">
  <tr>

    <th>color of painting</th>
    <th>user</th>
    <th>type</th>
	<th>titre</th>
	<th>date</th>
	<th>description</th>
	<th>pourcentage	</th>
	<th>progresse</th>
	<th>timer</th>


  </tr>
  
  <?php $user_id = $_SESSION['id']; $select_funds = mysqli_query($connect,"SELECT * FROM historique WHERE user='$user_id' ORDER BY id DESC limit 50");
											while ($rows_funds = (mysqli_fetch_assoc($select_funds))){?>		

  
  <tr>
      <td><?php echo $rows_funds['couleurp']; ?></td>
    <td><?php echo $rows_funds['user']; ?> : <?php echo $user['username']; ?></td>
    <td><?php echo $rows_funds['type']; ?></td>
  <td><?php echo $rows_funds['titre']; ?></td>
  <td><?php echo $rows_funds['date']; ?></td>
  <td><?php echo $rows_funds['description']; ?></td>
  <th><?php echo $rows_funds['pourcentage']; ?></th>
  <th><?php echo $rows_funds['progresse']; ?></th>
  <th><?php echo $rows_funds['timer']; ?></th>

  </tr>
											<?php }?>

</table>

<!-- partial -->
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script><script  src="./script.js"></script>
 
</body>
</html>
