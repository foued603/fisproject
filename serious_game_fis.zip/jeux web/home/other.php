<!DOCTYPE html>
<?php session_start(); ?>

<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>logs</title>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js" type="text/javascript"></script>
	<link rel="stylesheet" type="text/css" href="css/demo.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel="stylesheet" href="css/logtable.css">
		<link rel="stylesheet" type="text/css" href="css/normalize.css" />
		<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.3.0/css/font-awesome.min.css" />
				<link rel="stylesheet" type="text/css" href="css/menustyle.css" />
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel='stylesheet' href='https://rsms.me/inter/inter.css'><link rel="stylesheet" href="./style.css">

</head>
<?php 


include('../inc/connect.php');
include('../inc/select_user.php');

?>
<?php if(empty($_SESSION['id'])){?>
				<?php }if(!empty($_SESSION['id'])){
				$user = user($_SESSION['id']);	
				 }?>
<body>
	<nav class="navbar">
  <ul class="menu">

    <li>
      <a href="index.php">Home</a>
    </li>
    <li>
      <a href="profile.php">Profile</a>
    </li>
    <li>
      <a href="logs.php">Logs</a>
    </li>
    <li>
      <a href="settigns.php">Setttings</a>
    </li>
    <li>
      <a href="other.php">instruction</a>
    </li>
		 <li>
      <a href="../inc/logout.php">Logout</a>
    </li>
    <ul>
</nav>
		
<!-- partial:index.partial.html -->
<section class="c-section">
  <h2 class="c-section__title"><span>Intruction</span></h2>
  <ul class="c-services">


	<?php $user_id = $_SESSION['id']; $select_funds = mysqli_query($connect,"SELECT * FROM instruction ORDER BY id DESC limit 100");
											while ($rows_funds = (mysqli_fetch_assoc($select_funds))){?>		
	  <li class="c-services__item">
      <h3><?php echo $rows_funds['titre']; ?></h3>
      <p><?php echo $rows_funds['description']; ?> </p>
    </li>
											<?php } ?>
	
  </ul>
  
  
  
  
</section>

<!-- partial -->
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script><script  src="./script.js"></script>
   <script  src="./script.js"></script>

</body>
</html>
