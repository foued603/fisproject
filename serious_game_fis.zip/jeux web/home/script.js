// My submission for learncssgarden.com challenge
// === === ===
// UI Inspired from: https://dribbble.com/afterglow-studio
// svg icon:........ https://thenounproject.com
// svg illustration: https://undraw.co/illustrations