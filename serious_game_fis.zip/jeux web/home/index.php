<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en" class="no-js">
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5ec9ce3ec75cbf1769eec27c/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
 <?php 
	if(empty($_SESSION['id'])){ ?>
	<script>
	document.location.href="../index.php";
	
	</script>	
	
	<?php } ?>

	<head>

		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" href="favicon.ico">
		<link rel="stylesheet" type="text/css" href="css/normalize.css" />
		<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.3.0/css/font-awesome.min.css" />
		<link rel="stylesheet" type="text/css" href="css/demo.css" />
		<link rel="stylesheet" type="text/css" href="css/loader.css" />
		<link rel="stylesheet" type="text/css" href="css/border.css" />

				<link rel="stylesheet" type="text/css" href="notifix/notiflix-2.0.0.css" />
<style>

.cursorstyle {
cursor: not-allowed;
}
</style>


   <link rel="stylesheet" type="text/css" href="css/animate.min.css">
   
	
    <link rel="stylesheet" type="text/css" href="css/template-3d-animation.css">

				<link rel="stylesheet" type="text/css" href="css/menustyle.css" />

		<script src="js/modernizr.custom.js"></script>
	</head>
	<?php 
include('../inc/connect.php');

?>
	<body>
	
	
	<script type="text/javascript">
	
		<?php 


				$lastid = mysqli_insert_id($connect);
					$select_notification = mysqli_query($connect,"SELECT * FROM notification where id=1");
						while($rows_notification = (mysqli_fetch_assoc($select_notification))){
							
							
						
?>


    // Notification 1
    setTimeout(function() {
        var time = "notfication avaible for 10 seconde";
		var texte = "we hide the color red";
        $.notify({
            icon: 'img/email.png',
		title: '<?php echo $rows_notification['titre']; }?>',			
            message: '<button onclick=Notiflix.Report.Info("Email","","OK");>Open</button>'
        },{
            type: 'minimalist',
            placement: {
                from: "bottom",
                align: "left"
            },
            animate: {
                enter: 'animated fadeInLeftBig',
                exit: 'animated fadeOutLeftBig'
            },
            icon_type: 'image',
            template: '<div data-notify="container" class="alert alert-{0}" role="alert">' +
                '<button type="button" aria-hidden="true" class="close" data-notify="dismiss">×</button>' +
                '<div id="image">' +
                '<img data-notify="icon" class="rounded-circle float-left">' +
                '</div><div id="text">' +
                '<span data-notify="title">{1}</span>' +
                '<span data-notify="message">{2}</span>' +
                '<span data-notify="time">'+time+'</span>' +
                '</div>'+
            '</div>'
        });
    },1000);

   


	
	</script>
	
	<nav class="navbar">
  <ul class="menu">

    <li>
      <a href="index.php">Home</a>
    </li>
    <li>
      <a href="profile.php">Profile</a>
    </li>
    <li>
      <a href="logs.php">Logs</a>
    </li>
    <li>
      <a href="settigns.php">Setttings</a>
    </li>
    <li>
      <a href="other.php">instruction</a>
    </li>
	 <li>
      <a href="../inc/logout.php">Logout</a>
    </li>
    <ul>
	
</nav>


		<div class="container">
	<h4> i need something ( +3 seconde )</h4>
	<select name="select" id="select_something">
    <option value="">--Please choose an option--</option>
    <option value="color">color hidden</option>
	    <option value="extracolor">add extra color</option>

	<option value="hidenumber">hide number or change it</option>
	

</select>
<input type="button" value="request" onclick="need_some_thing()">
			<div class="content">

<div class="Content">
<ul class="List">



  <li class="List-item">
  
		<div class="ProgressBar ProgressBar--animateAll1" data-progress="" id="prr1">
    	<svg class="ProgressBar-contentCircle">
				<!-- on défini le l'angle et le centre de rotation du cercle -->
			<circle transform="rotate(-90, 100, 100)" class="ProgressBar-background1" cx="25" cy="25" r="23.75"></circle>
			<circle transform="rotate(-90, 100, 100)" class="ProgressBar-circle" cx="25" cy="25" r="23.75" style="stroke-dasharray: 597px; stroke-dashoffset: 119.4px;"></circle>
        <span class="ProgressBar-percentage1 ProgressBar-percentage--count"></span>
			</svg>
		</div>
		
  </li>
  
  <li class="List-item1">
  
		<div class="ProgressBar ProgressBar--animateAll2" data-progress="" id="prr2">
    	<svg class="ProgressBar-contentCircle">
				<!-- on défini le l'angle et le centre de rotation du cercle -->
			<circle transform="rotate(-90, 100, 100)" class="ProgressBar-background2" cx="25" cy="25" r="23.75"></circle>
			<circle transform="rotate(-90, 100, 100)" class="ProgressBar-circle" cx="25" cy="25" r="23.75" style="stroke-dasharray: 597px; stroke-dashoffset: 119.4px;"></circle>
        <span class="ProgressBar-percentage2 ProgressBar-percentage--count"></span>
			</svg>
		</div>
		
  </li>

	  <li class="List-item1">
  
		<div class="ProgressBar ProgressBar--animateAll3" data-progress="" id="prr3">
    	<svg class="ProgressBar-contentCircle">
				<!-- on défini le l'angle et le centre de rotation du cercle -->
			<circle transform="rotate(-90, 100, 100)" class="ProgressBar-background3" cx="25" cy="25" r="23.75"></circle>
			<circle transform="rotate(-90, 100, 100)" class="ProgressBar-circle" cx="25" cy="25" r="23.75" style="stroke-dasharray: 597px; stroke-dashoffset: 119.4px;"></circle>
        <span class="ProgressBar-percentage3 ProgressBar-percentage--count"></span>
			</svg>
		</div>
		
  </li>
  	  <li class="List-item1">
  
		<div class="ProgressBar ProgressBar--animateAll4" data-progress="" id="prr4">
    	<svg class="ProgressBar-contentCircle">
				<!-- on défini le l'angle et le centre de rotation du cercle -->
			<circle transform="rotate(-90, 100, 100)" class="ProgressBar-background4" cx="25" cy="25" r="23.75"></circle>
			<circle transform="rotate(-90, 100, 100)" class="ProgressBar-circle" cx="25" cy="25" r="23.75" style="stroke-dasharray: 597px; stroke-dashoffset: 119.4px;"></circle>
        <span class="ProgressBar-percentage4 ProgressBar-percentage--count"></span>
			</svg>
		</div>
		
  </li>
  	  <li class="List-item1">
  
		<div class="ProgressBar ProgressBar--animateAll5" data-progress="" id="prr5">
    	<svg class="ProgressBar-contentCircle">
				<!-- on défini le l'angle et le centre de rotation du cercle -->
			<circle transform="rotate(-90, 100, 100)" class="ProgressBar-background5" cx="25" cy="25" r="23.75"></circle>
			<circle transform="rotate(-90, 100, 100)" class="ProgressBar-circle" cx="25" cy="25" r="23.75" style="stroke-dasharray: 597px; stroke-dashoffset: 119.4px;"></circle>
        <span class="ProgressBar-percentage5 ProgressBar-percentage--count"></span>
			</svg>
		</div>
		
  </li>
  	  <li class="List-item1">
  
		<div class="ProgressBar ProgressBar--animateAll6" data-progress="" id="prr6">
    	<svg class="ProgressBar-contentCircle">
				<!-- on défini le l'angle et le centre de rotation du cercle -->
			<circle transform="rotate(-90, 100, 100)" class="ProgressBar-background6" cx="25" cy="25" r="23.75"></circle>
			<circle transform="rotate(-90, 100, 100)" class="ProgressBar-circle" cx="25" cy="25" r="23.75" style="stroke-dasharray: 597px; stroke-dashoffset: 119.4px;"></circle>
        <span class="ProgressBar-percentage6 ProgressBar-percentage--count"></span>
			</svg>
		</div>
		
  </li>
    <li class="List-item1">
  
		<div class="ProgressBar ProgressBar--animateAll7" data-progress="16" id="prr7">
    	<svg class="ProgressBar-contentCircle">
				<!-- on défini le l'angle et le centre de rotation du cercle -->
			<circle transform="rotate(-90, 100, 100)" class="ProgressBar-background7" cx="25" cy="25" r="23.75"></circle>
			<circle transform="rotate(-90, 100, 100)" class="ProgressBar-circle" cx="25" cy="25" r="23.75" style="stroke-dasharray: 597px; stroke-dashoffset: 119.4px;"></circle>
        <span class="ProgressBar-percentage7 ProgressBar-percentage--count"></span>
			</svg>
		</div>
		
  </li>
</ul>
</div>

<table border="1" cellpadding="15" class="table_p" id="matable" >

<tr id="tbl">
<tr id="tb2">
<tr id="tb3">
<tr id="tb4">
<tr id="tb5">
<tr id="tb6">

</table>
<div id="myProgress">
  <div id="myBar">0%</div>
</div>


			</div>
			
			<div class="customizer">
				<ul class="color-tool">
				<input type="button" value="get stat" onclick="testt()">
					<div id="hide1"><li class="color-3"><div class="drag-element" data-color="#c0c3d5" ><div class="drop color-3" onclick="myFunction()" id="id0"><p class="p_p">0</p></div><i class="drop-helper-1 color-3"></i><i class="drop-helper-2 color-3"></i><i class="drop-helper-3 color-3"></i><i class="drop-helper-3 color-3"></i></div></li></div>
					<div id="hide2"><li class="color-4"><div class="drag-element" data-color="#5FA1E0"><div class="drop color-4" onclick="myFunction2()" id="id1" ><p class="p_p">1</p></div><i class="drop-helper-1 color-4"></i><i class="drop-helper-2 color-4"></i><i class="drop-helper-3 color-4"></i><i class="drop-helper-4 color-4"></i></div></li></div>
					<div id="hide3"><li class="color-5"><div class="drag-element" data-color="#C1D5C0"><div class="drop color-5" onclick="myFunction3()" id="id2"><p class="p_p">2</p></div><i class="drop-helper-1 color-5"></i><i class="drop-helper-2 color-5"></i><i class="drop-helper-3 color-5"></i><i class="drop-helper-4 color-5"></i></div></li></div>
					<div id="hide4"><li class="color-6"><div class="drag-element" data-color="#47AE73"><div class="drop color-6" onclick="myFunction4()" id="id3"><p class="p_p">3</p></div><i class="drop-helper-1 color-6"></i><i class="drop-helper-2 color-6"></i><i class="drop-helper-3 color-6"></i><i class="drop-helper-4 color-6"></i></div></li></div>
					<div id="hide5"><li class="color-7"><div class="drag-element" data-color="#EAE7C4"><div class="drop color-7" onclick="myFunction5()" id="id4"><p class="p_p">4</p></div><i class="drop-helper-1 color-7"></i><i class="drop-helper-2 color-7"></i><i class="drop-helper-3 color-7"></i><i class="drop-helper-4 color-7"></i></div></li></div>
					<div id="hide6"><li class="color-8"><div class="drag-element" data-color="#FB6964" ><div class="drop color-8" onclick="myFunction6()" id="id5" ><p class="p_p">5</p></div><i class="drop-helper-1 color-8"></i><i class="drop-helper-2 color-8"></i><i class="drop-helper-3 color-8"></i><i class="drop-helper-4 color-8"></i></div></li></div>
					<div id="hide7" style="visibility: hidden;"><li class="color-9"><div class="drag-element" data-color="#FCF800" ><div class="drop color-9" onclick="myFunction7()" id="id6" ><p class="p_p">6</p></div><i class="drop-helper-1 color-9"></i><i class="drop-helper-2 color-9"></i><i class="drop-helper-3 color-9"></i><i class="drop-helper-4 color-9"></i></div></li></div>
					<div id="hide8" style="visibility: hidden;"><li class="color-10"><div class="drag-element" data-color="#" ><div class="drop color-10" onclick="myFunction()" id="id10"><p class="p_p"></p></div><i class="drop-helper-1 color-10"></i><i class="drop-helper-2 color-10"></i><i class="drop-helper-3 color-10"></i><i class="drop-helper-3 color-10"></i></div></li></div>

				<input type="color">
					

					<li><button class="reset-button" title="Reser colors">Reset colors</button></li>
				</ul>
			</div>
			<div class="customizer_right">
<h4 class="color-tool">choose a Speed</h4><br>
<label class="color-tool">One Second
  <input type="radio" name="radio" id="radio1" value="1000" >
</label>
<label class="color-tool">Two Second
  <input type="radio" name="radio" id="radio2" value="2000">
</label>
<label class="color-tool">Three Second
  <input type="radio" name="radio" id="radio3" value="3000">
</label>
<label class="color-tool">Four Second
  <input type="radio" name="radio" id="radio4" value="4000">
  <label class="color-tool">default
  <input type="radio" name="radio" id="radio4" value="6000" checked>
  
</label>

				</div>
			<!-- Related demos -->

<label>Choose a option:</label>
<select name="select" id="select_cases" onchange="ChangeCarList()">
    <option value="">--Please choose an option--</option>
    <option value="1">case 1</option>
    <option value="2">case 2</option>
    <option value="3">case 3</option>
    <option value="4">case 4</option>
</select>
<select id="carmodel"></select> 

<input type="button" onclick="fncase1()" value="Ok">
<input type="button" id="alea1" onclick="alea()" value="1">
<input type="button" onclick="refresh()" value="refresh">


		
			<div class="info-wrap">
				<div class="info">
					<h3>Game Time management</h3>
					<p><img src="img/drag.svg" alt="drag icon"/>Drag any color from the left toolbar to the case in the table.</p>
					<p><img src="img/time.png" alt="drag icon"/>The color is blocked for a while time </p>
					<button class="info-close">Got it!</button>
				</div>
			</div>     
			
			<div class="footer">
<h1 id="chrono"><time>00 00:00:00.000</time></h1>
<button id="start">start</button>
<button id="stop">stop</button>
<button id="clear">clear</button>
</div>
		</div><!-- /container -->
<!-- lorsqu'il prend le focus appel le blocage -->

<p id="sucess"></p>
<p id="erreur"></p>

<img src="img/mantime.png" alt="Smiley face" height="350" width="150" style="
    margin-left: 74%;
    margin-top: -22%;
">	

<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.1.5/angular.min.js"></script>

  <script src="js/vendors.min.js"></script>
		<script src="js/bloque.js"></script>
		<script src="js/classie.js"></script>
		<script src="js/interact-1.2.4.min.js"></script>
		<script src="js/main.js"></script>
		<script src="js/chrono.js"></script>
		<script src="js/tableau.js"></script>
		<script src="js/cases.js"></script>
		<script src="js/occurence.js"></script>
		<script src="js/progresse.js"></script>

		<script src="notifix/notiflix-2.0.0.js"></script>


	</body>
</html>
