let timeout = null;

// Nos unités de temps
let milliseconds = 0;
let seconds = 35;
let minutes = 59;
let hours = 23;
let days = 0;

// DOM elements
let chrono = document.querySelector('#chrono');
let clear  = document.querySelector('#clear');
let start  = document.querySelector('#start');
let stop   = document.querySelector('#stop');

// Ajoute 10 a l'unite de base qui est millisecondes
// Incremente les secondes, minutes et heures en fonction de cet etalon.
function add() {
    milliseconds += 10;

    if (milliseconds >= 1000){
        milliseconds = 0;
        seconds++;
        if (seconds >= 60){
            seconds = 0;
            minutes++;
        }
        if (minutes >= 60){
            minutes = 0;
            hours++;
        }
        if (hours >= 24){
            hours = 0;
            days++;
        }
    }

    chrono.textContent = (days ? (days > 9 ? days : "0" + days) : "00") + " " +
                         (hours ? (hours > 9 ? hours : "0" + hours) : "00") + ":" +
                         (minutes ? (minutes > 9 ? minutes : "0" + minutes) : "00") + ":" +
                         (seconds > 9 ? seconds : "0" + seconds) + "." + milliseconds;
    timer();
}

// Execute notre fonction add() dans 10 millisecondes
function timer(){
    timeout = setTimeout(add, 10);
}

function clean_timeout(){
    clearTimeout(timeout);
    timeout = null;
}

// Definitions de nos evenements
start.onclick = function(){
    if (!timeout)
        timer();
};

stop.onclick = function(){
    clean_timeout();
}

clear.onclick = function(){
    clean_timeout();
    chrono.textContent = "00 00:00:00.000";
    milliseconds = 0; seconds = 0; minutes = 0; hours = 0; days = 0;
}