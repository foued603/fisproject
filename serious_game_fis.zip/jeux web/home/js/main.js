(function() {
var sucess=0;
var erreur=0;
	var docElem = window.document.documentElement,
		// transition end event name
		transEndEventNames = { 'WebkitTransition': 'webkitTransitionEnd', 'MozTransition': 'transitionend', 'OTransition': 'oTransitionEnd', 'msTransition': 'MSTransitionEnd', 'transition': 'transitionend' },
		transEndEventName = transEndEventNames[ Modernizr.prefixed( 'transition' ) ];

	function scrollX() { return window.pageXOffset || docElem.scrollLeft; }
	function scrollY() { return window.pageYOffset || docElem.scrollTop; }
	function getOffset(el) {
		var offset = el.getBoundingClientRect();
		return { top : offset.top + scrollY(), left : offset.left + scrollX() };
	}

	function dragMoveListener(event) {
		var target = event.target,
			// keep the dragged position in the data-x/data-y attributes
			x = (parseFloat(target.getAttribute('data-x')) || 0) + event.dx,
			y = (parseFloat(target.getAttribute('data-y')) || 0) + event.dy;

		// translate the element
		target.style.transform = target.style.webkitTransform = 'translate(' + x + 'px, ' + y + 'px)';
		target.style.zIndex = 10000;

		// update the posiion attributes
		target.setAttribute('data-x', x);
		target.setAttribute('data-y', y);
	}

	function revertDraggable(el) {
		el.style.transform = el.style.webkitTransform = 'none';
		el.style.zIndex = 1;
		el.setAttribute('data-x', 0);
		el.setAttribute('data-y', 0);
	}

	function init() {
		var i=0;
		document.querySelector('button.info-close').addEventListener('click', function() {
			var info = document.querySelector('.info-wrap');
			info.parentNode.removeChild(info);
		});

		// target elements with the "drag-element" class
		interact('.drag-element').draggable({
			// enable inertial throwing
			inertia: true,
			// call this function on every dragmove event
			onmove: dragMoveListener,
			onend: function (event) {
				if(!classie.has(event.target, 'drag-element--dropped') && !classie.has(event.target, 'drag-element--dropped-text')) {
					revertDraggable(event.target);
				}
			}
		});

		// enable draggables to be dropped into this
		interact('.paint-area').dropzone({
			// only accept elements matching this CSS selector
			accept: '.drag-element',
			// Require a 75% element overlap for a drop to be possible
			overlap: 0.75,
			
		
			ondragleave: function (event) {
				classie.remove(event.target, 'paint-area--highlight');
				
			},
			
			ondrop: function (event) {
				var type = 'area';
				if(classie.has(event.target, 'paint-area--text')) {
					type = 'text';
				}

				var draggableElement = event.relatedTarget;

				classie.add(draggableElement, type === 'text' ? 'drag-element--dropped-text' : 'drag-element--dropped');

				var onEndTransCallbackFn = function(ev) {
					this.removeEventListener( transEndEventName, onEndTransCallbackFn );
					if( type === 'area' ) {
						paintArea(event.dragEvent, event.target, draggableElement.getAttribute('data-color'));
						i++;
						
						// var zero = ("#c0c3d5");
						// if (draggableElement.getAttribute('data-color')==zero){
						// alert("zero");
						// }

							
					
					var datacolor = draggableElement.getAttribute('data-color');
						
							
						var pourcentagebar = (i/36)*100;
						var myBar = document.getElementById("myBar");
						myBar.style.width=pourcentagebar+"%";
						document.getElementById("myBar").innerHTML=pourcentagebar.toFixed(2)+"%";
						if ( pourcentagebar==100) {
														
							Notiflix.Report.Success( 'Good job', '"Do not try to become a person of success but try to become a person of value." <br><br>- Albert Einstein', 'Done' ); 
							
							
						}
					}
					setTimeout(function() {
						revertDraggable(draggableElement);
						classie.remove(draggableElement, type === 'text' ? 'drag-element--dropped-text' : 'drag-element--dropped');
					}, type === 'text' ? 0 : 250);
					
					
						function paintArea(ev, el, color) {
		var type = 'area';
		if(classie.has(el, 'paint-area--text')) {
			type = 'text';
		}

		if( type === 'area' ) {
			// create SVG element
			var dummy = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
			dummy.setAttributeNS(null, 'version', '1.1');
			dummy.setAttributeNS(null, 'width', '100%');
			dummy.setAttributeNS(null, 'height', '100%');
			dummy.setAttributeNS(null, 'class', 'paint');

			var g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
			g.setAttributeNS(null, 'transform', 'translate(' + Number(ev.pageX - getOffset(el).left) + ', ' + Number(ev.pageY - getOffset(el).top) + ')');

			var circle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
			circle.setAttributeNS(null, 'cx', 0);
			circle.setAttributeNS(null, 'cy', 0);
			circle.setAttributeNS(null, 'r', Math.sqrt(Math.pow(el.offsetWidth,2) + Math.pow(el.offsetHeight,2)));
			circle.setAttributeNS(null, 'fill', color);

			dummy.appendChild(g);
			g.appendChild(circle);
			el.appendChild(dummy);
		}

		setTimeout(function() {
			classie.add(el, 'paint--active');

			if( type === 'text' ) {
				el.style.color = color;
				var onEndTransCallbackFn = function(ev) {
					if( ev.target != this ) return;
					this.removeEventListener( transEndEventName, onEndTransCallbackFn );
					classie.remove(el, 'paint--active');
				};

				el.addEventListener(transEndEventName, onEndTransCallbackFn);
			}
			else {
				var onEndTransCallbackFn = function(ev) {
					if( ev.target != this || ev.propertyName === 'fill-opacity' ) return;
					this.removeEventListener(transEndEventName, onEndTransCallbackFn);
					// set the color
					el.style.backgroundColor = color;
					var bgrouge = ("rgb(251, 105, 100)");
					var color0 = ("#c0c3d5");
					var color1 = ("#5FA1E0");
					var color2 = ("#C1D5C0");
					var color3 = ("#47AE73");
					var color4 = ("#EAE7C4");					
					var color5 = ("#FB6964");
					var color6 = ("#FCF800");
					var numerocase = el.innerText;
					
	if ( (draggableElement.getAttribute('data-color')==color0) && ( numerocase == 0 ) ) {
			Notiflix.Notify.Success('true 0 -> gris');
				
				sucess = sucess+1;

			
					
			}
						

				else if ( (draggableElement.getAttribute('data-color')==color1) && ( numerocase == 1 ) ){
			
			Notiflix.Notify.Success('true 1 -> blue');
			sucess = sucess+1;
			}
				else if ( (draggableElement.getAttribute('data-color')==color2) && ( numerocase == 2 ) ){
			
			Notiflix.Notify.Success('true 2 -> vert fancé');
			sucess = sucess+1;
			
			}
				else if ( (draggableElement.getAttribute('data-color')==color3) && ( numerocase == 3 ) ){
			
			Notiflix.Notify.Success('true 3 -> vert');
			sucess = sucess+1;
			
			}
				else if ( (draggableElement.getAttribute('data-color')==color4) && ( numerocase == 4 ) ){
			
			Notiflix.Notify.Success('true 4 -> moutard ');
			sucess = sucess+1;
			
			}
				else if ( (draggableElement.getAttribute('data-color')==color5) && ( numerocase == 5 ) ){
			
			Notiflix.Notify.Success('true 5 -> rouge');
			sucess = sucess+1;
			
			}
					else if ( (draggableElement.getAttribute('data-color')==color6) && ( numerocase == 6 ) ){
			
			Notiflix.Notify.Success('true 6 -> jaune');
			sucess = sucess+1;
			
			}

	else{ 
			
	Notiflix.Notify.Failure("Error");
	
	erreur=erreur+1;

			}	
var a =0;

	document.getElementById("sucess").innerHTML = " nombre de success : " +sucess;
	document.getElementById("erreur").innerHTML = " nombre de erreur : " +erreur;
	

					// remove SVG element
					el.removeChild(dummy);

					setTimeout(function() { classie.remove(el, 'paint--active'); }, 25);
				};
				circle.addEventListener(transEndEventName, onEndTransCallbackFn);
			
			}
		}, 25);
	}

					
					
				};
				
				draggableElement.querySelector('.drop').addEventListener(transEndEventName, onEndTransCallbackFn);
			},
			ondropdeactivate: function (event) {
				// remove active dropzone feedback
				classie.remove(event.target, 'paint-area--highlight');
				
			},
			
			ondragenter: function (event) {
				
				classie.add(event.target, 'paint-area--highlight');
				

			// curseur change
					
			}
		
		});

		// reset colors
		document.querySelector('button.reset-button').addEventListener('click', resetColors);
		
	}


	function resetColors() {
		[].slice.call(document.querySelectorAll('.paint-area')).forEach(function(el) {
			el.style[classie.has(el, 'paint-area--text') ? 'color' : 'background-color'] = '';
		});
	}

	init();

})();

