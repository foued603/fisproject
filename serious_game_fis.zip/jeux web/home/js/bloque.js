
  var id0 = document.getElementById("id0");
    var id1 = document.getElementById("id1");
	 var id2 = document.getElementById("id2");
	  var id3 =  document.getElementById("id3");
		 var id4 =  document.getElementById("id4");
		  var id5 =  document.getElementById("id5");
		  		  var id6 =  document.getElementById("id6");


function myFunction() {
var radio = document.getElementsByName('radio');
var valeur;
for(var i = 0; i < radio.length; i++){
    if(radio[i].checked){
             valeur = radio[i].value;
    }
}



	  timer1 = setTimeout(function(){ id0.className = "loader" }, 500);
    timer2 = setTimeout(function(){ id0.className = "drop color-3" }, valeur);
	
	 timer11 = setTimeout(function(){ id1.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id1.className = "drop color-4" }, valeur);
	
 timer11 = setTimeout(function(){ id2.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id2.className = "drop color-5" }, valeur);
	 
	 timer11 = setTimeout(function(){ id3.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id3.className = "drop color-6" }, valeur);
	
	 timer11 = setTimeout(function(){ id4.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id4.className = "drop color-7" }, valeur);	
	
	timer11 = setTimeout(function(){ id5.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id5.className = "drop color-8" }, valeur);	

	timer11 = setTimeout(function(){ id6.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id6.className = "drop color-9" }, valeur);	

}
function myFunction2() {
var radio = document.getElementsByName('radio');
var valeur;
for(var i = 0; i < radio.length; i++){
    if(radio[i].checked){
             valeur = radio[i].value;
    }
}

  timer1 = setTimeout(function(){ id0.className = "loader" }, 500);
    timer2 = setTimeout(function(){ id0.className = "drop color-3" }, valeur);
	
	 timer11 = setTimeout(function(){ id1.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id1.className = "drop color-4" }, valeur);
	
 timer11 = setTimeout(function(){ id2.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id2.className = "drop color-5" }, valeur);
	 
	 timer11 = setTimeout(function(){ id3.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id3.className = "drop color-6" }, valeur);
	
	 timer11 = setTimeout(function(){ id4.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id4.className = "drop color-7" }, valeur);	
	
	timer11 = setTimeout(function(){ id5.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id5.className = "drop color-8" }, valeur);	

	timer11 = setTimeout(function(){ id6.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id6.className = "drop color-9" }, valeur);	
	

}
function myFunction3() {
var radio = document.getElementsByName('radio');
var valeur;
for(var i = 0; i < radio.length; i++){
    if(radio[i].checked){
             valeur = radio[i].value;
    }
}

   timer1 = setTimeout(function(){ id0.className = "loader" }, 500);
    timer2 = setTimeout(function(){ id0.className = "drop color-3" }, valeur);
	
	 timer11 = setTimeout(function(){ id1.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id1.className = "drop color-4" }, valeur);
	
 timer11 = setTimeout(function(){ id2.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id2.className = "drop color-5" }, valeur);
	 
	 timer11 = setTimeout(function(){ id3.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id3.className = "drop color-6" }, valeur);
	
	 timer11 = setTimeout(function(){ id4.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id4.className = "drop color-7" }, valeur);	
	
	timer11 = setTimeout(function(){ id5.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id5.className = "drop color-8" }, valeur);	

	timer11 = setTimeout(function(){ id6.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id6.className = "drop color-9" }, valeur);	
	

}

function myFunction4() {
var radio = document.getElementsByName('radio');
var valeur;
for(var i = 0; i < radio.length; i++){
    if(radio[i].checked){
             valeur = radio[i].value;
    }
}

   timer1 = setTimeout(function(){ id0.className = "loader" }, 500);
    timer2 = setTimeout(function(){ id0.className = "drop color-3" }, valeur);
	
	 timer11 = setTimeout(function(){ id1.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id1.className = "drop color-4" }, valeur);
	
 timer11 = setTimeout(function(){ id2.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id2.className = "drop color-5" }, valeur);
	 
	 timer11 = setTimeout(function(){ id3.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id3.className = "drop color-6" }, valeur);
	
	 timer11 = setTimeout(function(){ id4.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id4.className = "drop color-7" }, valeur);	
	
	timer11 = setTimeout(function(){ id5.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id5.className = "drop color-8" }, valeur);	

	timer11 = setTimeout(function(){ id6.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id6.className = "drop color-9" }, valeur);	

}
function myFunction5() {
var radio = document.getElementsByName('radio');
var valeur;
for(var i = 0; i < radio.length; i++){
    if(radio[i].checked){
             valeur = radio[i].value;
    }
}

 timer1 = setTimeout(function(){ id0.className = "loader" }, 500);
    timer2 = setTimeout(function(){ id0.className = "drop color-3" }, valeur);
	
	 timer11 = setTimeout(function(){ id1.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id1.className = "drop color-4" }, valeur);
	
 timer11 = setTimeout(function(){ id2.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id2.className = "drop color-5" }, valeur);
	 
	 timer11 = setTimeout(function(){ id3.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id3.className = "drop color-6" }, valeur);
	
	 timer11 = setTimeout(function(){ id4.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id4.className = "drop color-7" }, valeur);	
	
	timer11 = setTimeout(function(){ id5.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id5.className = "drop color-8" }, valeur);	

	timer11 = setTimeout(function(){ id6.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id6.className = "drop color-9" }, valeur);	

}
function myFunction6() {
var radio = document.getElementsByName('radio');
var valeur;
for(var i = 0; i < radio.length; i++){
    if(radio[i].checked){
             valeur = radio[i].value;
    }
}

  timer1 = setTimeout(function(){ id0.className = "loader" }, 500);
    timer2 = setTimeout(function(){ id0.className = "drop color-3" }, valeur);
	
	 timer11 = setTimeout(function(){ id1.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id1.className = "drop color-4" }, valeur);
	
 timer11 = setTimeout(function(){ id2.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id2.className = "drop color-5" }, valeur);
	 
	 timer11 = setTimeout(function(){ id3.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id3.className = "drop color-6" }, valeur);
	
	 timer11 = setTimeout(function(){ id4.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id4.className = "drop color-7" }, valeur);	
	
	timer11 = setTimeout(function(){ id5.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id5.className = "drop color-8" }, valeur);	

	timer11 = setTimeout(function(){ id6.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id6.className = "drop color-9" }, valeur);	
	

}




function myFunction7() {
var radio = document.getElementsByName('radio');
var valeur;
for(var i = 0; i < radio.length; i++){
    if(radio[i].checked){
             valeur = radio[i].value;
    }
}

 timer1 = setTimeout(function(){ id0.className = "loader" }, 500);
    timer2 = setTimeout(function(){ id0.className = "drop color-3" }, valeur);
	
	 timer11 = setTimeout(function(){ id1.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id1.className = "drop color-4" }, valeur);
	
 timer11 = setTimeout(function(){ id2.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id2.className = "drop color-5" }, valeur);
	 
	 timer11 = setTimeout(function(){ id3.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id3.className = "drop color-6" }, valeur);
	
	 timer11 = setTimeout(function(){ id4.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id4.className = "drop color-7" }, valeur);	
	
	timer11 = setTimeout(function(){ id5.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id5.className = "drop color-8" }, valeur);	

	timer11 = setTimeout(function(){ id6.className = "loader" }, 500);
    timer22 = setTimeout(function(){ id6.className = "drop color-9" }, valeur);	
	

}


