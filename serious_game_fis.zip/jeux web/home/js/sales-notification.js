	<?php 
include('../../inc/connect.php');


				$lastid = mysqli_insert_id($connect);
					$select_notification = mysqli_query($connect,"SELECT * FROM notification where id=1");
						while($rows_notification = (mysqli_fetch_assoc($select_notification))){
							
							
						
?>


$(window).on('load', function() {
    // Notification 1
    setTimeout(function() {
        var time = "notfication avaible for 10 seconde";
		var texte = "we hide the color red";
        $.notify({
            icon: 'img/email.png',
		title: '<?php echo $rows_notification['titre']; }?>',			
            message: '<button onclick=Notiflix.Report.Info("Email","","OK");>Open</button>'
        },{
            type: 'minimalist',
            placement: {
                from: "bottom",
                align: "left"
            },
            animate: {
                enter: 'animated fadeInLeftBig',
                exit: 'animated fadeOutLeftBig'
            },
            icon_type: 'image',
            template: '<div data-notify="container" class="alert alert-{0}" role="alert">' +
                '<button type="button" aria-hidden="true" class="close" data-notify="dismiss">×</button>' +
                '<div id="image">' +
                '<img data-notify="icon" class="rounded-circle float-left">' +
                '</div><div id="text">' +
                '<span data-notify="title">{1}</span>' +
                '<span data-notify="message">{2}</span>' +
                '<span data-notify="time">'+time+'</span>' +
                '</div>'+
            '</div>'
        });
    },1000);

   
});

