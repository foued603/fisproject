
var carsAndModels = {};
carsAndModels['1'] = ['0', '1', '2', '3', '4', '5'];
function ChangeCarList() {
	 var carList = document.getElementById("select_cases");
var modelList = document.getElementById("carmodel");
  var selCar = carList.options[carList.selectedIndex].value;
  while (modelList.options.length) {
    modelList.remove(0);
  }
 var cars = carsAndModels[selCar];
  if (cars) {
    var i;
    for (i = 0; i < cars.length; i++) {
      var select_cases = new Option(cars[i], i);

      modelList.options.add(select_cases);
    }
  }	
}
function fncase1(){
var x = document.getElementById("carmodel").value;
  if ( x=="0" ){
  document.getElementById("hide1").style.visibility = "hidden";
  }	 
    if ( x=="1" ){
  document.getElementById("hide2").style.visibility = "hidden";
  }	 
      if ( x=="2" ){
  document.getElementById("hide3").style.visibility = "hidden";
  }	 
      if ( x=="3" ){
  document.getElementById("hide4").style.visibility = "hidden";
  }	 
      if ( x=="4" ){
  document.getElementById("hide5").style.visibility = "hidden";
  }	 
      if ( x=="5" ){
  document.getElementById("hide6").style.visibility = "hidden";
  }	 

}
function need_some_thing(){
	var color_select = document.getElementById("select_something").value;
	if (color_select=="color") {
  document.getElementById("hide6").style.visibility = "visible";
  alert("Good job -3 seconde");
  alert(x);
  
	}
	
		if (color_select=="hidenumber") {
			var answer = prompt("what is the number:");
			if (answer != 6 ) {
   answer  = "User cancelled the prompt.";
    }
	if (answer=="6"){
			  alert("Good job -3 seconde");
  }

  
	}
	if (color_select=="extracolor") {
			var answer = prompt("what is the number:");
			if (answer == 6 ) {
		  document.getElementById("hide7").style.visibility = "visible";
			} else { alert("wrong answer");}
	}
}
