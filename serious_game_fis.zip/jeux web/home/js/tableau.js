function alea(){
x = document.getElementById("alea1").value;
}

document.getElementById("tbl");
for (var i = 0; i < 6; i++) {
  var para = document.createElement("td");
  para.className = 'mockup-heading mockup-heading--box paint-area';
  para.innerText = Math.floor(Math.random() * 6);
  document.getElementById("tbl").appendChild(para);
  
}

		document.getElementById("tb2");
for (var i = 0; i < 6; i++) {
  var para = document.createElement("td");
  para.className = 'mockup-heading mockup-heading--box paint-area';
  para.innerText = Math.floor(Math.random() * 6);
  document.getElementById("tb2").appendChild(para);
}
   
		document.getElementById("tb3");
for (var i = 0; i < 6; i++) {
  var para = document.createElement("td");
  para.className = 'mockup-heading mockup-heading--box paint-area';
  para.innerText = Math.floor(Math.random() * 6);
  document.getElementById("tb3").appendChild(para);
}
       
		document.getElementById("tb4");
for (var i = 0; i < 6; i++) {
  var para = document.createElement("td");
  para.className = 'mockup-heading mockup-heading--box paint-area';
  para.innerText = Math.floor(Math.random() * 6);
  document.getElementById("tb4").appendChild(para);
}
       
			document.getElementById("tb5");
for (var i = 0; i < 6; i++) {
  var para = document.createElement("td");
  para.className = 'mockup-heading mockup-heading--box paint-area';
  para.innerText = Math.floor(Math.random() * 6);
  document.getElementById("tb5").appendChild(para);
}
       

function refresh(){
	var s=6+parseInt(x);
	document.getElementById("tb6");
for (var i = 0; i < 6; i++) {
  var para = document.createElement("td");
  para.className = 'mockup-heading mockup-heading--box paint-area';
  para.innerText = Math.floor(Math.random() * s);
  document.getElementById("tb6").appendChild(para);
}

}




