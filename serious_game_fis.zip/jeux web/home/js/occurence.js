
var numtab="";
		for ( var j = 0 ; j < 5 ; j++ ){
		for ( var i = 0 ; i < 6 ; i++ ){
	

  x = document.getElementById("matable").rows[j].cells[i];
 numtab = numtab + x.innerHTML;


}

}




var counts = {};

for (var k = 0; k < numtab.length; k++) {
  var num = numtab[k];
  counts[num] = counts[num] ? counts[num] + 1 : 1;
}



var c0 = counts[0];
var c1 = counts[1];
var c2 = counts[2];
var c3 = counts[3];
var c4 = counts[4];
var c5 = counts[5];
var c6 = counts[6];

var rll = document.getElementById("matable").rows.length;
var cll = document.getElementById("matable").rows[0].cells.length;

var x1 = parseInt(rll);
var x2 = parseInt(cll);
var n = x1*x2;

var pc0 = (c0/n)*100;
var pc1 = (c1/n)*100;
var pc2 = (c2/n)*100;
var pc3 = (c3/n)*100;
var pc4 = (c4/n)*100;
var pc5 = (c5/n)*100;
var pc6 = (c6/n)*100;


var gtt = document.getElementById("prr1");
gtt.setAttribute('data-progress', Math.round(pc0));

var gtt = document.getElementById("prr2");
gtt.setAttribute('data-progress', Math.round(pc1));

var gtt = document.getElementById("prr3");
gtt.setAttribute('data-progress', Math.round(pc2));

var gtt = document.getElementById("prr4");
gtt.setAttribute('data-progress', Math.round(pc3));

var gtt = document.getElementById("prr5");
gtt.setAttribute('data-progress', Math.round(pc4));

var gtt = document.getElementById("prr6");
gtt.setAttribute('data-progress', Math.round(pc5));






	
var nms = document.getElementsByClassName("mockup-heading mockup-heading--box paint-area");

for ( var c =0; c < n; c++ ){
if ( nms[c].innerText == 1 ) {
	
	nms[c].style.color="#5FA1E0";
}
if ( nms[c].innerText == 2 ) {
	
	nms[c].style.color="#c1d5c0";
}

if ( nms[c].innerText == 3 ) {
	
	nms[c].style.color="#47AE73";
}

if ( nms[c].innerText == 4 ) {
	
	nms[c].style.color="#eae7c4";
}

if ( nms[c].innerText == 5 ) {
	
	nms[c].style.color="#FB6964";
}

if ( nms[c].innerText == 6 ) {
	
	nms[c].style.color="#FCF800";
}

if ( nms[c].innerText == 0 ) {
	
	nms[c].style.color="#c0c3d5";
}


}







