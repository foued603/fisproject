<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en" >
 <?php 
	if(!empty($_SESSION['id'])){ ?>
	<script>
	document.location.href="home/index.php";
	
	</script>	
	
	<?php } ?>
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
<link rel="stylesheet" href="./style.css">

</head>
<?php 
include('inc/connect.php');
?>

<body>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5ec9ce3ec75cbf1769eec27c/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
<!-- partial:index.partial.html -->
<input class="logic-checkbox" type="checkbox" id="toggleGame"/>
<input class="logic-checkbox" type="checkbox" id="HowToPlayPopup"/>
<input class="logic-checkbox" type="checkbox" id="whoAmIPopup"/>
<input class="logic-checkbox" type="checkbox" id="GraphicsLevel"/>
<section class="game-menu-frame">
  <header class="game-header">
    <h1 class="game-title"> 
      <div class="line-1"> Serious Game</div>
      <div class="line-2">By FIS</div>
      <div class="line-3">Let's enjoy together!</div>
    </h1>
  </header>
  <nav class="game-nav">
    <h2 class="game-nav-title">Main Menu</h2>
    <ul class="game-nav-list">
      <li class="game-nav-item" > 
		      <li class="game-nav-item"> <a class="game-nav-button" href="home/index.php">Start game</a></li>

      </li>
      <li class="game-nav-item"> 
      <li class="game-nav-item"> <a class="game-nav-button" href="login.php">Login</a></li>
      </li>
      <li class="game-nav-item"> 
      <li class="game-nav-item"> <a class="game-nav-button" href="register.php">Signup</a></li>
      </li>
      <li class="game-nav-item"> 
        <label class="game-nav-button" for="whoAmIPopup" tabindex="0">instruction</label>
      </li>
      <li class="game-nav-item"> <a class="game-nav-button" href="https://fisglobal.com">Quitter</a></li>
    </ul>
    <p class="note">Let's beat this on together and on the way spend time doing good.</p>
  </nav>
  <div class="corona-promo-virus-1">
    <label class="corona-virus">
      <div class="body">
        <div class="scalp"><span class="hair1"></span><span class="hair2"></span><span class="hair3"></span><span class="hair4"></span><span class="hair5"></span><span class="hair6"></span><span class="hair7"></span><span class="hair8"></span><span class="hair9"></span><span class="hair10"></span><span class="hair11"></span><span class="hair12"></span>
        </div>
        <div class="eye1"></div>
        <div class="eye2"></div>
      </div>
    </label>
  </div>
  <div class="corona-promo-virus-2">
    <label class="corona-virus">
      <div class="body">
        <div class="scalp"><span class="hair1"></span><span class="hair2"></span><span class="hair3"></span><span class="hair4"></span><span class="hair5"></span><span class="hair6"></span><span class="hair7"></span><span class="hair8"></span><span class="hair9"></span><span class="hair10"></span><span class="hair11"></span><span class="hair12"></span>
        </div>
        <div class="eye1"></div>
        <div class="eye2"></div>
      </div>
    </label>
  </div>
</section>



<section class="popup common-content" id="whoAmI">
  <label class="close-button" for="whoAmIPopup" tabindex="0">x</label>
    <?php $lastid = mysqli_insert_id($connect);
					$select_instruction = mysqli_query($connect,"SELECT * FROM instruction where id=1");
						while($rows_instruction = (mysqli_fetch_assoc($select_instruction))){
							?>
  <h3 class="common-title"><?php echo $rows_instruction['titre']; ?></h3>
  <p><?php echo $rows_instruction['description']; ?></p>
  <label class="game-nav-button" for="whoAmIPopup" tabindex="0">Close</label>
	
									  	<?php	}
					?>   			
				 
</section>
<section class="popup common-content" id="HowToPlay">
  <label class="close-button" for="HowToPlayPopup" tabindex="0">x</label>
  <h3 class="common-title">Inscription</h3>
  <p>E_Number :   <input type="text" name="login"/></p>
 <p> Login : <input type="text" name="login"/></p>
  <p>Mot de passe :<input type="text" name="login"/></p>
    <p>Position :<input type="text" name="login"/></p>
    <p> <input type="button" name="login" value="Valider"/></p>

  
  <label class="game-nav-button" for="HowToPlayPopup" tabindex="0">Close</label>
</section>
<!-- partial -->
  <script  src="./script.js"></script>

</body>
</html>
