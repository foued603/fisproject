<?php 
	
	$db = mysqli_connect('localhost', 'root', '', 'jeux_fis');


        $id = $_POST['id'];
	    $username = $_POST['username'];
		$nom = $_POST['nom'];
        $prenom = $_POST['prenom'];
        $date_naissence = $_POST['date_naissence'];
        $email = $_POST['email'];
       // $password = $_POST['password'];
        $pays = $_POST['pays'];
        $num_tel = $_POST['num_tel'];
        
       // echo $username;
        //echo $nom;
        //echo $prenom;
       // echo $id;
        //echo $password;
    
        
		mysqli_query($db, "UPDATE `utilisateur` SET `username`='$username',`nom`='$nom',`prenom`='$prenom',`date_naissence`='$date_naissence',`email`='$email',`num_tel`='$num_tel',`pays`='$pays'  WHERE id=$id"); 
        header('location: user.php');
        

    
    


?>