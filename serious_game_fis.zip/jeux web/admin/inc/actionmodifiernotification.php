<?php 
	
	$db = mysqli_connect('localhost', 'root', '', 'jeux_fis');


        $id = $_POST['id'];
	    $titre = $_POST['titre'];
			    $type = $_POST['titre'];

		$description = $_POST['description'];
       		$click = $_POST['click'];
					$temps = $_POST['temps'];


        
		mysqli_query($db, "UPDATE `notification` SET `titre`='$titre',`type`='$type' , `description`='$description'  ,`click`='$click' ,`temps`='$temps' WHERE id=$id"); 
        header('location: ../listenotification.php');
        

    
    


?>