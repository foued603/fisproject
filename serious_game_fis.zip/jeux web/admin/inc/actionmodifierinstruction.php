<?php 
	
	$db = mysqli_connect('localhost', 'root', '', 'jeux_fis');


        $id = $_POST['id'];
	    $titre = $_POST['titre'];
		$description = $_POST['description'];
       
        
		mysqli_query($db, "UPDATE `instruction` SET `titre`='$titre',`description`='$description' WHERE id=$id"); 
        header('location: ../listeinstruction.php');
        

    
    


?>