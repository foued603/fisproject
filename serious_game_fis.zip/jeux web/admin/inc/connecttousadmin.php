<?php
include('connect.php');
include('verif_usernameadmin.php');
$username = $_POST['username'];
$password = $_POST['password'];
$username = mysqli_real_escape_string($connect,$username);
$password = mysqli_real_escape_string($connect,$password);
$verif_username = verif_username($username);
if ((!empty($username)) && (!empty($password))){
		if($verif_username == true){
			if(($verif_username['password']) == $password){
				$result = $verif_username['id'];
				session_start();
				$_SESSION['id'] = $verif_username['id'];
			}else{
			$result="password";
			}
		}if($verif_username == false){
		$result="usernamenot";
		}
}if ((empty($username)) or (empty($password))){
	$result="nothing";
}echo json_encode($result);
?>