<?php 
	
	$db = mysqli_connect('localhost', 'root', '', 'jeux_fis');



	    $title = $_POST['title'];
		$date = $_POST['date'];
        $description = $_POST['description'];
       
    
        
		mysqli_query($db, "INSERT INTO `instruction` (`id`, `titre`, `description`, `date`)  VALUES (NULL, '$title', '$description', '$date');    "); 
        header('location: ../ajouterinstruction.php');
		
        

    
    
/*

INSERT INTO utilisateur 
        (`username`, `nom`, `prenom`, `date_naissence`, `email`, `password`, `enumber`, `photo`, `statut`, `dateinsc`, `pays`, `document`, `num_tel`, `date`)
        VALUES ('username', 'nom', 'prenom', null, 'email', 'password','0','0','0',null,'pays','0', '0','0',null); 

        */

?>