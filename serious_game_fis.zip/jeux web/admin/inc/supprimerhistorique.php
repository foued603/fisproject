<?php
$db = mysqli_connect('localhost', 'root', '', 'jeux_fis');

if (isset($_GET['del'])) {
	$id = $_GET['del'];
	mysqli_query($db, "DELETE FROM historique WHERE id=$id");
	$_SESSION['message'] = "Address deleted!"; 
	header('location: ../listehistorique.php');
}


?>