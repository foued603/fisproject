<?php
function user($id){
include('connect.php');
$select_user = mysqli_query($connect,"SELECT * FROM utilisateur WHERE id='$id'");
return (mysqli_fetch_assoc($select_user));
}
?>