<?php 
$connect = mysqli_connect('localhost','root','','jeux_fis') or die ("erreur".mysqli_error());
mysqli_query($connect,"SET NAMES 'utf8'");
mysqli_query($connect,'SET CHARACTER SET utf8');
?>