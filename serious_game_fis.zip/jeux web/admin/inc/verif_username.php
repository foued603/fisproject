<?php
function verif_username($username){
include('connect.php');
$selectuser = mysqli_query($connect,"SELECT * FROM utilisateur WHERE username='{$username}'");
return (mysqli_fetch_assoc($selectuser));
}
?>