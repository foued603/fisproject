<?php 
	
	$db = mysqli_connect('localhost', 'root', '', 'jeux_fis');



	    $type = $_POST['type'];
		$titre = $_POST['titre'];
        $description = $_POST['description'];
		        $click =0;

               $temps = $_POST['temps'];

    
        
		mysqli_query($db, "INSERT INTO `notification` (`id`, `type`, `titre`, `description`, `temps`)  VALUES (NULL, '$type', '$titre', '$description' , '$temps');    "); 
        header('location: ../ajouternotification.php');
		
        

    
    
/*

INSERT INTO utilisateur 
        (`username`, `nom`, `prenom`, `date_naissence`, `email`, `password`, `enumber`, `photo`, `statut`, `dateinsc`, `pays`, `document`, `num_tel`, `date`)
        VALUES ('username', 'nom', 'prenom', null, 'email', 'password','0','0','0',null,'pays','0', '0','0',null); 

        */

?>