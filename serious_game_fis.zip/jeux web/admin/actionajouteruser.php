<?php 
	
	$db = mysqli_connect('localhost', 'root', '', 'jeux_fis');



	    $username = $_POST['username'];
		$nom = $_POST['nom'];
        $prenom = $_POST['prenom'];
        $date_naissence = $_POST['date_naissence'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $pays = $_POST['pays'];
        $num_tel = $_POST['num_tel'];
        /*
        echo $username;
        echo $nom;
        echo $prenom;
        echo $password;
        */
        
		mysqli_query($db, "INSERT INTO `utilisateur` (`id`, `username`, `nom`, `prenom`, `date_naissence`, `email`, `password`, `enumber`, `photo`, `statut`, `dateinsc`, `pays`, `document`, `num_tel`, `date`)  VALUES (NULL, '$username', '$nom', '$prenom', '2020-08-05', '$email', '$password', '', NULL, NULL, NULL, NULL, '$pays', '$num_tel', NULL);    "); 
        header('location: user.php');
        

    
    
/*

INSERT INTO utilisateur 
        (`username`, `nom`, `prenom`, `date_naissence`, `email`, `password`, `enumber`, `photo`, `statut`, `dateinsc`, `pays`, `document`, `num_tel`, `date`)
        VALUES ('username', 'nom', 'prenom', null, 'email', 'password','0','0','0',null,'pays','0', '0','0',null); 

        */

?>