$(document).ready(function(){
$("#body_inside_inside_in_all_login_box_log_button_b_connection").click(function(){
	var username = $("#body_inside_inside_in_all_login_box_log_into_username").val();
	var password = $("#body_inside_inside_in_all_login_box_log_into_password").val();
	$.ajax({
		type:'POST',
		url:'inc/connecttous.php',
		data:{
		username:username,
		password:password
		},
		dataType:'JSON',
		beforeSend:function(){
			document.getElementById('body_inside_inside_in_all_login_box_log_stat').style.display="inline-table";
			document.getElementById('body_inside_inside_in_all_login_box_log_stat').innerHTML="<img id='body_sign_up_msg_load_img' src='images/loading.gif'>";
		},
		success:function(rep){
		if(rep !== "nothing"){
					if(rep !== "usernamenot"){
						if(rep !== "password"){
						document.location.href="home/index.php";
						}if(rep == "password"){
						document.getElementById('body_inside_inside_in_all_login_box_log_stat').style.display="inline";
						document.getElementById('body_inside_inside_in_all_login_box_log_stat').innerHTML="The password is wrong.";
						}
					}if(rep == "usernamenot"){
						document.getElementById('body_inside_inside_in_all_login_box_log_stat').style.display="inline";
						document.getElementById('body_inside_inside_in_all_login_box_log_stat').innerHTML="The username does not exists.";
					}
			}if(rep == "nothing"){
			document.getElementById('body_inside_inside_in_all_login_box_log_stat').style.display="inline";
			document.getElementById('body_inside_inside_in_all_login_box_log_stat').innerHTML="You must fill out all the fields.";	
			}
		}
	});
});
});