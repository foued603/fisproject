$(document).ready(function(){
	$("#body_inside_inside_in_all_login_box_log_button_b_register").click(function(){
	var email = $("#body_inside_inside_in_all_login_box_log_into_email").val();
	var password = $("#body_inside_inside_in_all_login_box_log_into_pass").val();
	var dateb = $("#body_inside_inside_in_all_login_box_log_select_dateb").val(); // secret
	var phone = $("#body_inside_inside_in_all_login_box_log_into_phone").val(); // answer
	var country = $("#body_inside_inside_in_all_login_box_log_select_country").val();
	var prenom = $("#body_inside_inside_in_all_login_box_prenom").val(); // ref
	var enumber = $("#body_inside_inside_in_all_login_box_log_into_enumber").val(); // ref
	var username = $("#body_inside_inside_in_all_login_box_log_into_username").val(); // ref

	var patt= /[^0-9a-zA-Z]/;
	var emailRegex= /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
	


	if(!prenom.match(patt))
		if(password)
			if(!phone.match(patt))
				if(email.match(emailRegex))
				{
					
			$.ajax({
			type:'POST',
			url:'inc/register.php',
			data:{
			email:email,
			password:password,
			dateb:dateb,
			phone:phone,
			country:country,
			enumber:enumber,
			username:username,
			prenom:prenom},
			dataType:'JSON',
			beforeSend:function(){
				document.getElementById('body_sign_up_msg').style.display="inline-table";
				document.getElementById('body_sign_up_msg_load').innerHTML="<img id='body_sign_up_msg_load_img' src='img/loading.GIF'>";
			},
			success:function(rep){
				if (rep !== "nothing"){
		
					if (rep !== "email"){
						if (rep !== "emailreal"){
						if (rep !== "password"){
											
												if (rep !== "country"){
													document.location.href="index.php";
												}if (rep == "country"){
													document.getElementById('body_sign_up_msg_load').style.display="none";
													document.getElementById('body_sign_up_msg_register').innerHTML="You must choose your country";}	
										
											if (rep == "dateb"){
											document.getElementById('body_sign_up_msg_load').style.display="none";
											document.getElementById('body_sign_up_msg_register').innerHTML="You must choose a security dateb";}	
						}if (rep == "password"){
						document.getElementById('body_sign_up_msg_load').style.display="none";
						document.getElementById('body_sign_up_msg_register').innerHTML="The password must be 6 characters at least.";}
						}if (rep == "emailreal"){
						document.getElementById('body_sign_up_msg_load').style.display="none";
					document.getElementById('body_sign_up_msg_register').innerHTML="E-mail is already exists.";}
					}if (rep == "email"){
					document.getElementById('body_sign_up_msg_load').style.display="none";
					document.getElementById('body_sign_up_msg_register').innerHTML="The e-mail is not valid.";}
					
				
				}if (rep == "nothing"){
				document.getElementById('body_sign_up_msg_load').style.display="none";
				document.getElementById('body_sign_up_msg_register').innerHTML="You must fill out all the fields.";}	}
			});
				}
				else
					alert('Email non Valide');
			else
				alert('phone Incorrect');
		else
			alert('mot de passe invalide');
	else
		alert('prenom non valide');

	
		
			
			
			
			
			
			
		
		
	});
});