$(document).ready(function(){
	$("#body_inside_inside_inpage_inside_in_game_password").click(function(){
		var current = $("#body_inside_inside_inpage_inside_in_passcurrent").val();
		var newone = $("#body_inside_inside_inpage_inside_in_passnew").val();
		$.ajax({
		type:'POST',
		url:'inc/password.php',
		data:{
			current:current,
			newone:newone
		},
		dataType:'JSON',
		success:function(rep){
		if(rep == "done"){
		document.getElementById("body_inside_inside_inpage_inside_in_passcurrent").value="";
		document.getElementById("body_inside_inside_inpage_inside_in_passnew").value="";
		document.getElementById("body_inside_inside_inpage_inside_in_game_once_p_msg").innerHTML="<center><span id='body_inside_insidepage_info_passall_button_done'>Done</span></center>";
		}if(rep == "error"){
		document.getElementById("body_inside_inside_inpage_inside_in_game_once_p_msg").innerHTML="<span id='body_inside_insidepage_info_passall_button_done'>error</span>";
		}}
		});
	});
});