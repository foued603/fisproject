<?php
session_start();
include('connect.php');
include('verif_email.php');
include('totaluser.php');
$totaluser = totaluser();
$email = $_POST['email'];
$password = $_POST['password'];
$dateb = $_POST['dateb'];
$phone = $_POST['phone'];
$country = $_POST['country'];
$prenom = $_POST['prenom'];
$enumber = $_POST['enumber'];
$username = $_POST['username'];

$password = mysqli_real_escape_string($connect,$password);
$email = mysqli_real_escape_string($connect,$email);
$phone = mysqli_real_escape_string($connect,$phone);
$day = date("d");
$month = date("M");
$year = date("Y");
$date = $day." ".$month." ".$year;

if (!empty($email) && !empty($password) && !empty($phone)){

		$valid_email = filter_var($email,FILTER_VALIDATE_EMAIL);
		if($valid_email){
			$verif_email = verif_email($email);
			if(($verif_email) == false){
			if(strlen($password) > 5){
				if(!empty ($dateb )&& ($dateb !=="Security dateb")){
					if(!empty ($country )&& ($country !=="Country")){
									$mpnewmember = $totaluser['users'] + 1;
									$mpadd = mysqli_query($connect,"UPDATE totaluser SET users='$mpnewmember' WHERE id = 1");
									$register = mysqli_query($connect,"INSERT INTO utilisateur (email,password,date_naissence,num_tel,pays,prenom,date,enumber,username)VALUES('$email','$password','$dateb','$phone','$country','$prenom','$date','$enumber','$username')");
									$result = mysqli_insert_id($connect);
							
									$_SESSION['id'] = $result;
					}else{
					$result = "country";		
					}
				}else{
				$result = "dateb";	
				}				
			}else{
				$result = "password";
			}
		}if(($verif_email) == true){
			$result = "emailreal";
		}
		}if(!$valid_email){
			$result = "email";
		}


}if(empty($email) or empty($password) or empty($phone)){
$result = "nothing";}
echo json_encode($result);
?>