<?php
$day = date("j");
$month = date("M");
$year = date("Y");
$hour = date("h");
$minut = date("i");
$day = date("j");
$time = date("A");
echo $day." ".$month." ".$year." | ".$hour.":".$minut." ".$time;
?>