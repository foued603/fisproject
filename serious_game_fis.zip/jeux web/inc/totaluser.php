<?php
function totaluser(){
	include('connect.php');
	$pci = mysqli_query($connect,"SELECT * FROM totaluser WHERE id=1");
	return(mysqli_fetch_assoc($pci));
}
?>