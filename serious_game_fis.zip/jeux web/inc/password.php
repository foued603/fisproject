<?php
session_start();
include('connect.php');
include('select_user.php');
$user = user($_SESSION['id']);
$current = mysqli_real_escape_string($connect,$_POST['current']);
$newone = mysqli_real_escape_string($connect,$_POST['newone']);
if(!empty($newone)){
if(strlen($newone) > 5){
if(($user['password']) == $current){
$userid = $user['id'];
$updatepass = mysqli_query($connect,"UPDATE user_info SET password = '$newone' WHERE id='$userid'");
$result = "done";
}if(($user['password']) !== $current){
$result = "error";	
}}else{
$result = "error";	
}}else{
$result = "error";	
}
echo json_encode($result);
?>