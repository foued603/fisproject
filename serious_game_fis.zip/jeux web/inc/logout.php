<?php
session_start();
session_destroy();
$result = "destroyed";
echo json_encode($result);
if(! empty($_SESSION['id'])){
  header('Location: ../index.php');
  exit();
}
?>