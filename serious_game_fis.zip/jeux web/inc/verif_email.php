<?php
function verif_email($email){
include('connect.php');
$select = mysqli_query($connect,"SELECT * FROM utilisateur WHERE email='{$email}'");
return (mysqli_fetch_assoc($select));
}
?>