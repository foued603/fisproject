<?php session_start(); ?>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
<link rel="stylesheet" href="./style.css">
<link rel="stylesheet" href="css/style_insc.css">
</head>
<script src="jquery/jquery.js"></script>
<script src="jquery/register.js"></script>


<body>
<?php 
	include('inc/connect.php');
?>
<?php 
if(!empty($_SESSION['id'])){ ?>
<script>
document.location.href="home/index.php";
</script>	
<?php } ?>
<!-- partial:index.partial.html -->
<input class="logic-checkbox" type="checkbox" id="toggleGame"/>
<input class="logic-checkbox" type="checkbox" id="HowToPlayPopup"/>
<input class="logic-checkbox" type="checkbox" id="whoAmIPopup"/>
<input class="logic-checkbox" type="checkbox" id="GraphicsLevel"/>
<section class="game-menu-frame">
  <header class="game-header">
    <h1 class="game-title"> 
      <div class="line-1"> Serious Game</div>
      <div class="line-2">By FIS</div>
      <div class="line-3">Inscription</div>
    </h1>
  </header>
  <nav class="game-nav">
<div id="loginform">
  <div id="mainregister">
    <h1>Register</h1>
	
  		<div class="col-lg-8 center no-padding" id="container_register_form">
	 <input class="input" type="text" placeholder="E-Number" id="body_inside_inside_in_all_login_box_log_into_enumber">
	 	 <input class="input" type="text" placeholder="User" id="body_inside_inside_in_all_login_box_log_into_username">
	  <input class="input" type="text" placeholder="phone" id="body_inside_inside_in_all_login_box_log_into_phone">
      <input class="input" type="password" placeholder="password" id="body_inside_inside_in_all_login_box_log_into_pass">
      <input class="input" type="text" placeholder="email" id="body_inside_inside_in_all_login_box_log_into_email">
      <input class="input" type="text" placeholder="prenom" id="body_inside_inside_in_all_login_box_prenom">
      <input class="input" type="text" placeholder="adresse" id="body_inside_inside_in_all_login_box_log_select_country">
	  <input class="input" type="date" placeholder="date of birth" id="body_inside_inside_in_all_login_box_log_select_dateb"> 

	  
      <input type="button" value="Inscription" class="nav_bouton_connect" id="body_inside_inside_in_all_login_box_log_button_b_register">
	  <a href="/jeux web">

<input type="button" value="Back" class="nav_bouton_connect" style="
    left: -3%;
"></a>
    <div id="note"><span>*Remplissez tous les champs, merci.</span></div>
    <br />
  </div>
  </div>   </div>

	<div id="body_sign_up_msg">
								<div id="body_sign_up_msg_load"></div>
								<div id="body_sign_up_msg_register"></div>
								</div>	
 
  </nav>
  <div class="corona-promo-virus-1">
    <label class="corona-virus">
      <div class="body">
        <div class="scalp"><span class="hair1"></span><span class="hair2"></span><span class="hair3"></span><span class="hair4"></span><span class="hair5"></span><span class="hair6"></span><span class="hair7"></span><span class="hair8"></span><span class="hair9"></span><span class="hair10"></span><span class="hair11"></span><span class="hair12"></span>
        </div>
        <div class="eye1"></div>
        <div class="eye2"></div>
      </div>
    </label>
  </div>
  <div class="corona-promo-virus-2">
    <label class="corona-virus">
      <div class="body">
        <div class="scalp"><span class="hair1"></span><span class="hair2"></span><span class="hair3"></span><span class="hair4"></span><span class="hair5"></span><span class="hair6"></span><span class="hair7"></span><span class="hair8"></span><span class="hair9"></span><span class="hair10"></span><span class="hair11"></span><span class="hair12"></span>
        </div>
        <div class="eye1"></div>
        <div class="eye2"></div>
      </div>
    </label>
  </div>
</section>





<!-- partial -->
     <script src="js/jquery.js"></script>
     <script src="js/plugins.js"></script>
     <script src="js/script.js"></script>

     <!--Template functions-->
     <script src="js/functions.js"></script>
	 <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
	<script src="js/index.js"></script>



</body>
</html>
